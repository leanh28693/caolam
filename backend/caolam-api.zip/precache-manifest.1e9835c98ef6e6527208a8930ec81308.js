self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2497e83f55d2997ac0e515bfac54e4f7",
    "url": "/material-dashboard-react/index.html"
  },
  {
    "revision": "d64ff0a5622c085cb2e3",
    "url": "/material-dashboard-react/static/css/2.b509d78a.chunk.css"
  },
  {
    "revision": "0584b623476a72968d52",
    "url": "/material-dashboard-react/static/css/main.0fa7ec49.chunk.css"
  },
  {
    "revision": "d64ff0a5622c085cb2e3",
    "url": "/material-dashboard-react/static/js/2.8a932823.chunk.js"
  },
  {
    "revision": "0584b623476a72968d52",
    "url": "/material-dashboard-react/static/js/main.5c9011a7.chunk.js"
  },
  {
    "revision": "e4ce04191639c8b244c9",
    "url": "/material-dashboard-react/static/js/runtime~main.f09aad84.js"
  },
  {
    "revision": "8880a65c57d7f031579335be153f64a0",
    "url": "/material-dashboard-react/static/media/marc.8880a65c.jpg"
  },
  {
    "revision": "b3430df1d7584fe9f407b41edc06c96c",
    "url": "/material-dashboard-react/static/media/sidebar-1.b3430df1.jpg"
  },
  {
    "revision": "310509c95512893dc661bd3a6b0d2a5d",
    "url": "/material-dashboard-react/static/media/sidebar-2.310509c9.jpg"
  },
  {
    "revision": "2503169017014036cf0dd0dd7c2a2b8a",
    "url": "/material-dashboard-react/static/media/sidebar-3.25031690.jpg"
  },
  {
    "revision": "fc9cb0538eb5a4dfd6fbb1bf6dd6189b",
    "url": "/material-dashboard-react/static/media/sidebar-4.fc9cb053.jpg"
  }
]);