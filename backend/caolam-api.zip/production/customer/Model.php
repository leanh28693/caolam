<?php
class Customer{
    // database connection and table name
    private $conn;
    private $table_name = "quanly_customer";
    // object properties
public $id;
public $name;
public $phone;
public $address;
public $id_ve;
public $date_create;
// public $email;
// constructor with $db as database connection
public function __construct($db){
    $this->conn = $db;
}
// read products
function getAll(){

    // select all query
    $query = "SELECT * FROM ".$this->table_name." ORDER BY id DESC" ;
    
    // prepare query statement
    $stmt = $this->conn->prepare($query);

    // execute query
    $stmt->execute();
    return $stmt;
}
function getOneByID($id){
    // select all query
    $query = "SELECT * FROM ".$this->table_name." WHERE id = ".$id."" ;
    
    // prepare query statement
    
    $stmt = $this->conn->prepare($query);

    // execute query
    $stmt->execute();
    return $stmt;
}
function getOneByname($start_time,$id_tuyen){
    // select all query
    $query = "SELECT * FROM ".$this->table_name." WHERE start_time = '".$start_time."' and id_tuyen = '".$id_tuyen."'" ;
    
    // prepare query statement
    $stmt = $this->conn->prepare($query);

    // execute query
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if($row >0){
        //echo('true');die;
        return true;
    }
    //echo('false');die;
    return false;
}
function getByParam($id_tuyen){

    // select all query
        $query = "SELECT * FROM ".$this->table_name." WHERE id_tuyen = ".$id_tuyen." ORDER BY id DESC" ;
    
    // prepare query statement
    $stmt = $this->conn->prepare($query);

    // execute query
    $stmt->execute();
    return $stmt;
}
function updateByID($id){
// select all query
    $query = "UPDATE ".$this->table_name." SET id_tuyen = '".$this->id_tuyen."', id_xe = '".$this->id_xe."', start_time = '".$this->start_time."' WHERE id = ".$id."" ;

// prepare query statement
$stmt = $this->conn->prepare($query);
// execute query
//var_dump($stmt);die;
if($stmt->execute()){
    return true;
}
return false;
}          
    
// used when filling up the update product form
function del($id){

// query to read single record
$query = "DELETE FROM " . $this->table_name . " WHERE id = ".$id;
// prepare query statement
$stmt = $this->conn->prepare( $query );

try{
    //var_dump($stmt);die;
    // execute query
    if($stmt->execute()){
        return true;
    }
}catch (Exception $e){
    echo($e);
}
    return false;
}
// create product
function create(){

// query to insert record
$query = "INSERT INTO
            " . $this->table_name . "
        SET
        name=:name, phone=:phone, address=:address, id_ve=:id_ve";

// prepare query

$stmt = $this->conn->prepare($query);

// sanitize
$this->name=htmlspecialchars(strip_tags($this->name));
$this->phone=htmlspecialchars(strip_tags($this->phone));
$this->address=htmlspecialchars(strip_tags($this->address));
$this->id_ve=htmlspecialchars(strip_tags($this->id_ve));

// bind values
$stmt->bindParam(":name", $this->name);
$stmt->bindParam(":phone", $this->phone);
$stmt->bindParam(":address", $this->address);
$stmt->bindParam(":id_ve", $this->id_ve);
//var_dump($stmt);die;
// execute query
if($stmt->execute()){
    return true;
}

return false;
 
}
}